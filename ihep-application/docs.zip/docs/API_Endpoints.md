GET /api/participants/{id}/financial-health
POST /api/income-opportunities/apply
GET /api/training-programs/available
POST /api/benefits-navigator/check-eligibility
